import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@supabase/supabase-js";
import DashboardLayout from "@/components/Dashboard/DashboardLayout";
import TabNavigation, { TabType } from "@/components/Dashboard/TabNavigation";
import ApiKeyManager from "@/components/ApiKeys/ApiKeyManager";
import DeviceList from "@/components/Devices/DeviceList";
import SendSMSForm from "@/components/SMS/SendSMSForm";
import BulkSMSForm from "@/components/SMS/BulkSMSForm";
import MessagesList from "@/components/Messages/MessagesList";
import MessageHistory from "@/components/Messages/MessageHistory";

const TEXTBEE_BASE_URL = "https://api.textbee.dev/api/v1";

interface Device {
  id: string;
  name: string;
  status: string;
  last_seen?: string;
}

interface ApiKey {
  id: string;
  name: string;
  key_value: string;
  created_at: string;
}

interface Message {
  id: string;
  sender: string;
  message: string;
  received_at: string;
}

interface HistoryItem {
  id: string;
  type: "sent" | "received";
  recipient?: string;
  sender?: string;
  message: string;
  status?: string;
  timestamp: string;
}

const Index = () => {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>("apiKeys");
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageHistory, setMessageHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedDeviceId, setSelectedDeviceId] = useState("");
  const [activeApiKey, setActiveApiKey] = useState("");
  const { toast } = useToast();
  const navigate = useNavigate();

  // Auth state management
  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setUser(session?.user ?? null);
        setAuthLoading(false);
        
        if (!session) {
          navigate("/auth");
        }
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setAuthLoading(false);
      
      if (!session) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (user) {
      fetchApiKeys();
    }
  }, [user]);

  const fetchApiKeys = async () => {
    const { data, error } = await supabase
      .from("api_keys")
      .select("*")
      .order("created_at", { ascending: false });

    if (!error && data) {
      setApiKeys(data);
      if (data.length > 0 && !activeApiKey) {
        setActiveApiKey(data[0].key_value);
      }
    }
  };

  const fetchDevices = async () => {
    if (!activeApiKey) {
      toast({
        title: "API Key Required",
        description: "Please set your TextBee API key first",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${TEXTBEE_BASE_URL}/gateway/devices`, {
        headers: {
          "x-api-key": activeApiKey,
        },
      });

      if (response.ok) {
        const data = await response.json();
        
        // Handle different response formats
        const devicesData = Array.isArray(data) ? data : (data.data || []);
        
        // Map TextBee device format to our format
        const mappedDevices = devicesData.map((device: any) => ({
          id: device._id || device.id,
          name: device.model || device.name || 'Unknown Device',
          status: device.enabled ? 'online' : 'offline',
          last_seen: device.updatedAt || device.last_seen,
        }));
        
        setDevices(mappedDevices);

        // Store devices in database
        const { data: { user } } = await supabase.auth.getUser();
        if (user && mappedDevices.length > 0) {
          for (const device of mappedDevices) {
            await supabase.from("devices").upsert(
              {
                device_id: device.id,
                user_id: user.id,
                name: device.name,
                status: device.status,
                last_seen: device.last_seen,
              },
              { onConflict: "device_id" }
            );
          }
        }

        toast({
          title: "Success",
          description: `Loaded ${mappedDevices.length} device${mappedDevices.length !== 1 ? "s" : ""}`,
        });
      } else {
        const errorData = await response.json().catch(() => ({}));
        toast({
          title: "Error",
          description: errorData.error || "Failed to fetch devices",
          variant: "destructive",
        });
        setDevices([]);
      }
    } catch (error) {
      console.error("Error fetching devices:", error);
      toast({
        title: "Error",
        description: "Failed to fetch devices",
        variant: "destructive",
      });
      setDevices([]);
    }
    setLoading(false);
  };

  const handleSendSMS = async (deviceId: string, recipient: string, message: string) => {
    if (!activeApiKey) {
      throw new Error("API key not set");
    }

    const response = await fetch(
      `${TEXTBEE_BASE_URL}/gateway/devices/${deviceId}/send-sms`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": activeApiKey,
        },
        body: JSON.stringify({
          recipients: [recipient],
          message: message,
        }),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to send SMS");
    }

    // Store in database
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from("sent_messages").insert({
        device_id: deviceId,
        user_id: user.id,
        recipient: recipient,
        message: message,
        status: "sent",
        is_bulk: false,
      });
    }
  };

  const handleSendBulkSMS = async (
    deviceId: string,
    recipients: string[],
    message: string
  ) => {
    if (!activeApiKey) {
      throw new Error("API key not set");
    }

    const response = await fetch(
      `${TEXTBEE_BASE_URL}/gateway/devices/${deviceId}/send-bulk-sms`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": activeApiKey,
        },
        body: JSON.stringify({
          recipients: recipients,
          message: message,
        }),
      }
    );

    if (!response.ok) {
      throw new Error("Failed to send bulk SMS");
    }

    // Store in database
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      for (const recipient of recipients) {
        await supabase.from("sent_messages").insert({
          device_id: deviceId,
          user_id: user.id,
          recipient: recipient,
          message: message,
          status: "sent",
          is_bulk: true,
        });
      }
    }
  };

  const fetchReceivedMessages = async () => {
    if (!activeApiKey || !selectedDeviceId) {
      toast({
        title: "Selection Required",
        description: "Please select a device first",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `${TEXTBEE_BASE_URL}/gateway/devices/${selectedDeviceId}/get-received-sms`,
        {
          headers: {
            "x-api-key": activeApiKey,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const messagesData = Array.isArray(data) ? data : (data.data || []);
        
        const mappedMessages = messagesData.map((msg: any) => ({
          id: msg._id || msg.id,
          sender: msg.sender || msg.from,
          message: msg.message || msg.text,
          received_at: msg.timestamp || msg.receivedAt || msg.created_at,
        }));
        
        setMessages(mappedMessages);

        // Store in database
        const { data: { user } } = await supabase.auth.getUser();
        if (user && mappedMessages.length > 0) {
          for (const message of mappedMessages) {
            await supabase.from("received_messages").upsert(
              {
                message_id: message.id,
                device_id: selectedDeviceId,
                user_id: user.id,
                sender: message.sender,
                message: message.message,
                received_at: message.received_at,
              },
              { onConflict: "message_id" }
            );
          }
        }

        toast({
          title: "Success",
          description: `Loaded ${mappedMessages.length} message${mappedMessages.length !== 1 ? "s" : ""}`,
        });
      } else {
        const errorData = await response.json().catch(() => ({}));
        toast({
          title: "Error",
          description: errorData.error || "Failed to fetch messages",
          variant: "destructive",
        });
        setMessages([]);
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
      toast({
        title: "Error",
        description: "Failed to fetch messages",
        variant: "destructive",
      });
      setMessages([]);
    }
    setLoading(false);
  };

  const fetchMessageHistory = async () => {
    if (!activeApiKey || !selectedDeviceId) {
      toast({
        title: "Selection Required",
        description: "Please select a device first",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `${TEXTBEE_BASE_URL}/gateway/devices/${selectedDeviceId}/messages`,
        {
          headers: {
            "x-api-key": activeApiKey,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const historyData = Array.isArray(data) ? data : (data.data || []);
        setMessageHistory(historyData);
        
        toast({
          title: "Success",
          description: `Loaded ${historyData.length} history item${historyData.length !== 1 ? "s" : ""}`,
        });
      } else {
        const errorData = await response.json().catch(() => ({}));
        toast({
          title: "Error",
          description: errorData.error || "Failed to fetch message history",
          variant: "destructive",
        });
        setMessageHistory([]);
      }
    } catch (error) {
      console.error("Error fetching message history:", error);
      toast({
        title: "Error",
        description: "Failed to fetch message history",
        variant: "destructive",
      });
      setMessageHistory([]);
    }
    setLoading(false);
  };

  const handleGenerateApiKey = async (name: string) => {
    setLoading(true);
    try {
      const response = await fetch(`${TEXTBEE_BASE_URL}/auth/api-keys`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": activeApiKey || "initial-key",
        },
        body: JSON.stringify({ name }),
      });

      if (response.ok) {
        const newKeyData = await response.json();
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from("api_keys").insert({
            name: name,
            user_id: user.id,
            key_value: newKeyData.key,
          });
        }
        
        fetchApiKeys();
        toast({
          title: "Success",
          description: "API key generated successfully",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to generate API key",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error generating API key:", error);
      toast({
        title: "Error",
        description: "Failed to generate API key",
        variant: "destructive",
      });
    }
    setLoading(false);
  };

  const handleSetActiveApiKey = (keyValue: string) => {
    setActiveApiKey(keyValue);
    toast({
      title: "Success",
      description: "API key set as active",
    });
  };

  const handleSetInitialKey = async (keyValue: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await supabase.from("api_keys").insert({
        name: "Primary API Key",
        user_id: user.id,
        key_value: keyValue,
      });
      await fetchApiKeys();
    }
    setActiveApiKey(keyValue);
    
    // Auto-switch to devices tab and fetch devices
    setActiveTab("devices");
    
    toast({
      title: "Success",
      description: "TextBee API key configured successfully. Fetching devices...",
    });
    
    // Fetch devices with the new key
    setTimeout(async () => {
      try {
        const response = await fetch(`${TEXTBEE_BASE_URL}/gateway/devices`, {
          headers: {
            "x-api-key": keyValue,
          },
        });

        if (response.ok) {
          const data = await response.json();
          
          // Handle different response formats
          const devicesData = Array.isArray(data) ? data : (data.data || []);
          
          // Map TextBee device format to our format
          const mappedDevices = devicesData.map((device: any) => ({
            id: device._id || device.id,
            name: device.model || device.name || 'Unknown Device',
            status: device.enabled ? 'online' : 'offline',
            last_seen: device.updatedAt || device.last_seen,
          }));
          
          setDevices(mappedDevices);

          if (user && mappedDevices.length > 0) {
            for (const device of mappedDevices) {
              await supabase.from("devices").upsert(
                {
                  device_id: device.id,
                  user_id: user.id,
                  name: device.name,
                  status: device.status,
                  last_seen: device.last_seen,
                },
                { onConflict: "device_id" }
              );
            }
          }

          toast({
            title: "Success",
            description: `Loaded ${mappedDevices.length} device${mappedDevices.length !== 1 ? "s" : ""}`,
          });
        } else {
          const errorData = await response.json().catch(() => ({}));
          toast({
            title: "Error",
            description: errorData.error || "Failed to fetch devices. Please check your API key.",
            variant: "destructive",
          });
          setDevices([]);
        }
      } catch (error) {
        console.error("Error fetching devices:", error);
        toast({
          title: "Error",
          description: "Failed to fetch devices",
          variant: "destructive",
        });
        setDevices([]);
      }
    }, 500);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast({
      title: "Signed out",
      description: "You have been signed out successfully",
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <DashboardLayout onSignOut={handleSignOut}>
      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />

      {activeTab === "apiKeys" && (
        <ApiKeyManager
          apiKeys={apiKeys}
          onGenerateKey={handleGenerateApiKey}
          onSetActive={handleSetActiveApiKey}
          activeApiKey={activeApiKey}
          onSetInitialKey={handleSetInitialKey}
        />
      )}

      {activeTab === "devices" && (
        <DeviceList
          devices={devices}
          loading={loading}
          onRefresh={fetchDevices}
          onSelectDevice={setSelectedDeviceId}
        />
      )}

      {activeTab === "sendSMS" && (
        <SendSMSForm devices={devices} onSend={handleSendSMS} />
      )}

      {activeTab === "bulkSMS" && (
        <BulkSMSForm devices={devices} onSend={handleSendBulkSMS} />
      )}

      {activeTab === "receivedMessages" && (
        <MessagesList
          messages={messages}
          devices={devices}
          selectedDeviceId={selectedDeviceId}
          loading={loading}
          onDeviceSelect={setSelectedDeviceId}
          onRefresh={fetchReceivedMessages}
        />
      )}

      {activeTab === "messageHistory" && (
        <MessageHistory
          history={messageHistory}
          devices={devices}
          selectedDeviceId={selectedDeviceId}
          loading={loading}
          onDeviceSelect={setSelectedDeviceId}
          onRefresh={fetchMessageHistory}
        />
      )}
    </DashboardLayout>
  );
};

export default Index;