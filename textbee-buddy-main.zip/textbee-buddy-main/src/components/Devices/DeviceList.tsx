import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Smartphone, RefreshCw, CheckCircle2, XCircle } from "lucide-react";

interface Device {
  id: string;
  name: string;
  status: string;
  last_seen?: string;
}

interface DeviceListProps {
  devices: Device[];
  loading: boolean;
  onRefresh: () => void;
  onSelectDevice: (deviceId: string) => void;
}

const DeviceList = ({ devices, loading, onRefresh, onSelectDevice }: DeviceListProps) => {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Card className="border-border/50 shadow-lg bg-gradient-to-br from-card to-card/95">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-primary" />
                Registered Devices
              </CardTitle>
              <CardDescription>
                {devices.length} device{devices.length !== 1 ? "s" : ""} connected
              </CardDescription>
            </div>
            <Button
              onClick={onRefresh}
              disabled={loading}
              variant="outline"
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            {devices.map((device) => (
              <Card
                key={device.id}
                className="border-border/50 hover:border-primary/50 transition-all hover:shadow-md cursor-pointer"
                onClick={() => onSelectDevice(device.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-lg mb-1">{device.name}</h4>
                      <p className="text-sm text-muted-foreground font-mono">
                        {device.id}
                      </p>
                    </div>
                    <Badge
                      variant={device.status === "online" ? "default" : "secondary"}
                      className="gap-1"
                    >
                      {device.status === "online" ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <XCircle className="w-3 h-3" />
                      )}
                      {device.status}
                    </Badge>
                  </div>
                  {device.last_seen && (
                    <p className="text-xs text-muted-foreground">
                      Last seen: {new Date(device.last_seen).toLocaleString()}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
          {devices.length === 0 && !loading && (
            <div className="text-center py-12 text-muted-foreground">
              <Smartphone className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No devices found. Click Refresh to fetch your devices.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DeviceList;