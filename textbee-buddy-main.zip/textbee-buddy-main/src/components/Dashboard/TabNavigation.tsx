import { Button } from "@/components/ui/button";
import { Key, Smartphone, Send, Users, Inbox, History } from "lucide-react";

export type TabType = "apiKeys" | "devices" | "sendSMS" | "bulkSMS" | "receivedMessages" | "messageHistory";

interface TabNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const tabs = [
  { id: "apiKeys" as TabType, label: "API Keys", icon: Key },
  { id: "devices" as TabType, label: "Devices", icon: Smartphone },
  { id: "sendSMS" as TabType, label: "Send SMS", icon: Send },
  { id: "bulkSMS" as TabType, label: "Bulk SMS", icon: Users },
  { id: "receivedMessages" as TabType, label: "Received", icon: Inbox },
  { id: "messageHistory" as TabType, label: "History", icon: History },
];

const TabNavigation = ({ activeTab, onTabChange }: TabNavigationProps) => {
  return (
    <div className="flex gap-2 flex-wrap mb-8 p-1 bg-muted/50 rounded-xl backdrop-blur-sm">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        
        return (
          <Button
            key={tab.id}
            variant={isActive ? "default" : "ghost"}
            onClick={() => onTabChange(tab.id)}
            className={`flex items-center gap-2 transition-all ${
              isActive 
                ? "bg-gradient-to-r from-primary to-accent shadow-md" 
                : "hover:bg-background/50"
            }`}
          >
            <Icon className="w-4 h-4" />
            <span className="hidden sm:inline">{tab.label}</span>
          </Button>
        );
      })}
    </div>
  );
};

export default TabNavigation;