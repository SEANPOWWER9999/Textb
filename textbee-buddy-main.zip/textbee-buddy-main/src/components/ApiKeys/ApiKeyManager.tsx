import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Key, Plus, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ApiKey {
  id: string;
  name: string;
  key_value: string;
  created_at: string;
}

interface ApiKeyManagerProps {
  apiKeys: ApiKey[];
  onGenerateKey: (name: string) => Promise<void>;
  onSetActive: (keyValue: string) => void;
  activeApiKey: string;
  onSetInitialKey: (key: string) => void;
}

const ApiKeyManager = ({ apiKeys, onGenerateKey, onSetActive, activeApiKey, onSetInitialKey }: ApiKeyManagerProps) => {
  const [newKeyName, setNewKeyName] = useState("");
  const [initialKey, setInitialKey] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!newKeyName.trim()) {
      toast({
        title: "Name required",
        description: "Please enter a name for the API key",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await onGenerateKey(newKeyName);
      setNewKeyName("");
    } finally {
      setLoading(false);
    }
  };

  const handleSetInitialKey = () => {
    if (!initialKey.trim()) {
      toast({
        title: "API key required",
        description: "Please enter your TextBee API key",
        variant: "destructive",
      });
      return;
    }
    onSetInitialKey(initialKey);
    setInitialKey("");
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {!activeApiKey && (
        <Card className="border-primary/50 shadow-lg bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="w-5 h-5 text-primary" />
              Set Your TextBee API Key
            </CardTitle>
            <CardDescription>Enter your existing TextBee API key to get started</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <Input
                type="password"
                placeholder="Your TextBee API Key"
                value={initialKey}
                onChange={(e) => setInitialKey(e.target.value)}
                className="flex-1"
              />
              <Button onClick={handleSetInitialKey} className="bg-gradient-to-r from-primary to-accent">
                <Key className="w-4 h-4 mr-2" />
                Set Key
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="border-border/50 shadow-lg bg-gradient-to-br from-card to-card/95">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-primary" />
            Generate New API Key
          </CardTitle>
          <CardDescription>Create a new TextBee API key</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <Input
              placeholder="API Key Name (e.g., Production Key)"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              className="flex-1"
            />
            <Button
              onClick={handleGenerate}
              disabled={loading}
              className="bg-gradient-to-r from-primary to-accent"
            >
              <Plus className="w-4 h-4 mr-2" />
              Generate
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5 text-primary" />
            Your API Keys
          </CardTitle>
          <CardDescription>
            {apiKeys.length === 0
              ? "No API keys yet. Generate one to get started."
              : `${apiKeys.length} API key${apiKeys.length > 1 ? "s" : ""} available`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {apiKeys.map((apiKey) => (
              <div
                key={apiKey.id}
                className="flex items-center justify-between p-4 rounded-lg border border-border/50 bg-muted/30 hover:bg-muted/50 transition-colors"
              >
                <div className="flex-1">
                  <p className="font-medium">{apiKey.name}</p>
                  <p className="text-sm text-muted-foreground">
                    Created: {new Date(apiKey.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onSetActive(apiKey.key_value)}
                  className="gap-2"
                >
                  <Check className="w-4 h-4" />
                  Set Active
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ApiKeyManager;