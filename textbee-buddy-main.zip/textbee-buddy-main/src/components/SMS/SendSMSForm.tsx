import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Device {
  id: string;
  name: string;
}

interface SendSMSFormProps {
  devices: Device[];
  onSend: (deviceId: string, recipient: string, message: string) => Promise<void>;
}

const SendSMSForm = ({ devices, onSend }: SendSMSFormProps) => {
  const [deviceId, setDeviceId] = useState("");
  const [recipient, setRecipient] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSend = async () => {
    if (!deviceId || !recipient || !message) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await onSend(deviceId, recipient, message);
      setRecipient("");
      setMessage("");
      toast({
        title: "Success",
        description: "SMS sent successfully!",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="animate-in fade-in duration-500">
      <Card className="border-border/50 shadow-lg bg-gradient-to-br from-card to-card/95 max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5 text-primary" />
            Send SMS
          </CardTitle>
          <CardDescription>Send a text message to a single recipient</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Select Device</label>
            <Select value={deviceId} onValueChange={setDeviceId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a device" />
              </SelectTrigger>
              <SelectContent>
                {devices.map((device) => (
                  <SelectItem key={device.id} value={device.id}>
                    {device.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Recipient Phone Number</label>
            <Input
              type="tel"
              placeholder="+1234567890"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Message</label>
            <Textarea
              placeholder="Type your message here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={6}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground mt-2">
              {message.length} characters
            </p>
          </div>

          <Button
            onClick={handleSend}
            disabled={loading || !deviceId || !recipient || !message}
            className="w-full bg-gradient-to-r from-primary to-accent"
            size="lg"
          >
            <Send className="w-4 h-4 mr-2" />
            Send SMS
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default SendSMSForm;