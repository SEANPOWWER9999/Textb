import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Device {
  id: string;
  name: string;
}

interface BulkSMSFormProps {
  devices: Device[];
  onSend: (deviceId: string, recipients: string[], message: string) => Promise<void>;
}

const BulkSMSForm = ({ devices, onSend }: BulkSMSFormProps) => {
  const [deviceId, setDeviceId] = useState("");
  const [recipients, setRecipients] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const recipientsList = recipients
    .split(",")
    .map((r) => r.trim())
    .filter((r) => r.length > 0);

  const handleSend = async () => {
    if (!deviceId || recipientsList.length === 0 || !message) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await onSend(deviceId, recipientsList, message);
      setRecipients("");
      setMessage("");
      toast({
        title: "Success",
        description: `Bulk SMS sent to ${recipientsList.length} recipient${
          recipientsList.length > 1 ? "s" : ""
        }!`,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="animate-in fade-in duration-500">
      <Card className="border-border/50 shadow-lg bg-gradient-to-br from-card to-card/95 max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Send Bulk SMS
          </CardTitle>
          <CardDescription>Send a text message to multiple recipients</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Select Device</label>
            <Select value={deviceId} onValueChange={setDeviceId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a device" />
              </SelectTrigger>
              <SelectContent>
                {devices.map((device) => (
                  <SelectItem key={device.id} value={device.id}>
                    {device.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">
              Recipients (comma-separated)
            </label>
            <Textarea
              placeholder="+1234567890, +0987654321, +1122334455"
              value={recipients}
              onChange={(e) => setRecipients(e.target.value)}
              rows={3}
              className="resize-none font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground mt-2">
              {recipientsList.length} recipient{recipientsList.length !== 1 ? "s" : ""}
            </p>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Message</label>
            <Textarea
              placeholder="Type your message here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={6}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground mt-2">
              {message.length} characters × {recipientsList.length} recipients
            </p>
          </div>

          <Button
            onClick={handleSend}
            disabled={loading || !deviceId || recipientsList.length === 0 || !message}
            className="w-full bg-gradient-to-r from-primary to-accent"
            size="lg"
          >
            <Send className="w-4 h-4 mr-2" />
            Send to {recipientsList.length} Recipient
            {recipientsList.length !== 1 ? "s" : ""}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default BulkSMSForm;