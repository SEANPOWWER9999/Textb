import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Inbox, RefreshCw } from "lucide-react";

interface Message {
  id: string;
  sender: string;
  message: string;
  received_at: string;
}

interface Device {
  id: string;
  name: string;
}

interface MessagesListProps {
  messages: Message[];
  devices: Device[];
  selectedDeviceId: string;
  loading: boolean;
  onDeviceSelect: (deviceId: string) => void;
  onRefresh: () => void;
}

const MessagesList = ({
  messages,
  devices,
  selectedDeviceId,
  loading,
  onDeviceSelect,
  onRefresh,
}: MessagesListProps) => {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Card className="border-border/50 shadow-lg bg-gradient-to-br from-card to-card/95">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <CardTitle className="flex items-center gap-2 mb-2">
                <Inbox className="w-5 h-5 text-primary" />
                Received Messages
              </CardTitle>
              <Select value={selectedDeviceId} onValueChange={onDeviceSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a device" />
                </SelectTrigger>
                <SelectContent>
                  {devices.map((device) => (
                    <SelectItem key={device.id} value={device.id}>
                      {device.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={onRefresh}
              disabled={loading || !selectedDeviceId}
              variant="outline"
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              Fetch Messages
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {messages.map((message) => (
              <Card
                key={message.id}
                className="border-border/50 hover:border-primary/30 transition-colors"
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div>
                      <Badge variant="outline" className="mb-2">
                        From: {message.sender}
                      </Badge>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {new Date(message.received_at).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed">{message.message}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          {messages.length === 0 && !loading && selectedDeviceId && (
            <div className="text-center py-12 text-muted-foreground">
              <Inbox className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No messages found. Click "Fetch Messages" to check for new messages.</p>
            </div>
          )}
          {!selectedDeviceId && (
            <div className="text-center py-12 text-muted-foreground">
              <Inbox className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Select a device to view received messages</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default MessagesList;