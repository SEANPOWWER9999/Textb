import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { History, RefreshCw, ArrowUpRight, ArrowDownLeft } from "lucide-react";

interface HistoryItem {
  id: string;
  type: "sent" | "received";
  recipient?: string;
  sender?: string;
  message: string;
  status?: string;
  timestamp: string;
}

interface Device {
  id: string;
  name: string;
}

interface MessageHistoryProps {
  history: HistoryItem[];
  devices: Device[];
  selectedDeviceId: string;
  loading: boolean;
  onDeviceSelect: (deviceId: string) => void;
  onRefresh: () => void;
}

const MessageHistory = ({
  history,
  devices,
  selectedDeviceId,
  loading,
  onDeviceSelect,
  onRefresh,
}: MessageHistoryProps) => {
  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <Card className="border-border/50 shadow-lg bg-gradient-to-br from-card to-card/95">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <CardTitle className="flex items-center gap-2 mb-2">
                <History className="w-5 h-5 text-primary" />
                Message History
              </CardTitle>
              <Select value={selectedDeviceId} onValueChange={onDeviceSelect}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a device" />
                </SelectTrigger>
                <SelectContent>
                  {devices.map((device) => (
                    <SelectItem key={device.id} value={device.id}>
                      {device.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              onClick={onRefresh}
              disabled={loading || !selectedDeviceId}
              variant="outline"
              className="gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              Fetch History
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {history.map((item) => (
              <Card
                key={item.id}
                className="border-border/50 hover:border-primary/30 transition-colors"
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div
                      className={`mt-1 p-2 rounded-lg ${
                        item.type === "sent"
                          ? "bg-primary/10 text-primary"
                          : "bg-accent/10 text-accent"
                      }`}
                    >
                      {item.type === "sent" ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <ArrowDownLeft className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div className="flex flex-wrap gap-2">
                          <Badge
                            variant={item.type === "sent" ? "default" : "secondary"}
                          >
                            {item.type}
                          </Badge>
                          {item.status && (
                            <Badge variant="outline">{item.status}</Badge>
                          )}
                          <Badge variant="outline">
                            {item.type === "sent"
                              ? `To: ${item.recipient}`
                              : `From: ${item.sender}`}
                          </Badge>
                        </div>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">
                          {new Date(item.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm leading-relaxed">{item.message}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          {history.length === 0 && !loading && selectedDeviceId && (
            <div className="text-center py-12 text-muted-foreground">
              <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No history found. Click "Fetch History" to view message history.</p>
            </div>
          )}
          {!selectedDeviceId && (
            <div className="text-center py-12 text-muted-foreground">
              <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Select a device to view message history</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default MessageHistory;